'use strict';

var c3App = angular.module('c3App', [
  'ui.router'
])
  .config(function ($stateProvider, $urlRouterProvider, $locationProvider) {
      $stateProvider
        .state('home',{
          url: '/home',
          controller: 'homectrl',
          templateUrl: 'app/views/home/home.html'
        });

	      $urlRouterProvider.otherwise('/home');
  });
