'use strict';

// angular.module('c3App')
  c3App.controller('homectrl', function ($scope, $state) {

    /* declare end Point Obj */
    var endPointObj =
    {
      "buttons":[+45,+21,-21,-44],
      "bars":[86,79,70],
      "limit":140
    };
    /* set first progressbar on page load */

    $scope.selectedBar = "0";

    /* function for calculate percentages of all progress bars */

    function calculatePercentagesDefault(obj){

      /* create percentages property */
      obj.percentages = [];
      angular.forEach(obj.bars, function(value, key) {
        this.push(getPercentage(value,obj.limit));
      }, obj.percentages);
    }
    /* function for get percentage*/

    function getPercentage(value,total){
      return Math.round(value/total*100);
    }

    /* function for calculate percentage on button click */

    $scope.calculatePercentage = function(value){
      $scope.percentages[$scope.selectedBar] = $scope.percentages[$scope.selectedBar] + value;

      /* condition for  set min percentage value 0 */

      if($scope.percentages[$scope.selectedBar] < 1){
        $scope.percentages[$scope.selectedBar] = 0;
      }
    }

    /* check existance of endPointObj on page load*/

    if(endPointObj){
      $scope.buttons = endPointObj.buttons;
      $scope.bars = endPointObj.bars;
      /* function call for calculate default percentage of all progress bars */
      calculatePercentagesDefault(endPointObj);
      /* check existance of percentages property in endPointObj */
      if(endPointObj.hasOwnProperty('percentages')){
        $scope.percentages = endPointObj.percentages;
      }
    }
  });
